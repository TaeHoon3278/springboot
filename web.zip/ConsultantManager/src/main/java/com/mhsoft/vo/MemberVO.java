package com.mhsoft.vo;

public class MemberVO {
	
}
